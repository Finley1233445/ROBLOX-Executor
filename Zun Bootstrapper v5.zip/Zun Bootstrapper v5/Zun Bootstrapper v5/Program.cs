﻿using AuthGG;
using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Net;

namespace Zun_Bootstrapper_v5
{
    class Program
    {
        static void Main(string[] args)
        {
            OnProgramStart.Initialize("App1111111111111111111", "891755", "ajVjuXVvam0QpdwaffRlIzXSGnTtID4sorV", "1.5");
            WebClient web = new WebClient();
            string Version = web.DownloadString("https://pastebin.com/raw/sHcweNRc");
            Console.Title = "Zun | Bootstrapper";
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("");
            Console.WriteLine("                                              ▒███████▒ █    ██  ███▄    █ ");
            Console.WriteLine("                                              ▒ ▒ ▒ ▄▀░ ██  ▓██▒ ██ ▀█   █ ");
            Console.WriteLine("                                              ░ ▒ ▄▀▒░ ▓██  ▒██░▓██  ▀█ ██▒");
            Console.WriteLine("                                                ▄▀▒   ░▓▓█  ░██░▓██▒  ▐▌██▒");
            Console.WriteLine("                                              ▒███████▒▒▒█████▓ ▒██░   ▓██░");
            Console.WriteLine("                                              ░▒▒ ▓░▒░▒░▒▓▒ ▒ ▒ ░ ▒░   ▒ ▒ ");
            Console.WriteLine("                                              ░░▒ ▒ ░ ▒░░▒░ ░ ░ ░ ░░   ░ ▒░");
            Console.WriteLine("                                              ░ ░ ░ ░ ░ ░░░ ░ ░    ░   ░ ░ ");
            Console.WriteLine("                                              ░ ░       ░              ░   ");
            Console.WriteLine("                                              ░                            ");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("");
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("                                          [");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.Write("1");
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("] Download");
            Console.Write("          [");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.Write("2");
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("] Discord\n");
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("                                          [");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.Write("3");
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("] Kill ZunSploit");
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("    [");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.Write("4");
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("] Kill ROBLOX\n\n");
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("                                                      [");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.Write("!");
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("] Choose: ");
            Console.WriteLine("");

            int option = int.Parse(Console.ReadLine());

            switch (option)
            {
                case 1:
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Clear();
                    Console.WriteLine("▓█████▄  ▒█████   █     █░███▄    █  ██▓     ▒█████   ▄▄▄      ▓█████▄ ");
                    Console.WriteLine("▒██▀ ██▌▒██▒  ██▒▓█░ █ ░█░██ ▀█   █ ▓██▒    ▒██▒  ██▒▒████▄    ▒██▀ ██▌");
                    Console.WriteLine("░██   █▌▒██░  ██▒▒█░ █ ░█▓██  ▀█ ██▒▒██░    ▒██░  ██▒▒██  ▀█▄  ░██   █▌");
                    Console.WriteLine("░▓█▄   ▌▒██   ██░░█░ █ ░█▓██▒  ▐▌██▒▒██░    ▒██   ██░░██▄▄▄▄██ ░▓█▄   ▌");
                    Console.WriteLine("░▒████▓ ░ ████▓▒░░░██▒██▓▒██░   ▓██░░██████▒░ ████▓▒░ ▓█   ▓██▒░▒████▓ ");
                    Console.WriteLine(" ▒▒▓  ▒ ░ ▒░▒░▒░ ░ ▓░▒ ▒ ░ ▒░   ▒ ▒ ░ ▒░▓  ░░ ▒░▒░▒░  ▒▒   ▓▒█░ ▒▒▓  ▒ ");
                    Console.WriteLine(" ░ ▒  ▒   ░ ▒ ▒░   ▒ ░ ░ ░ ░░   ░ ▒░░ ░ ▒  ░  ░ ▒ ▒░   ▒   ▒▒ ░ ░ ▒  ▒ ");
                    Console.WriteLine(" ░ ░  ░ ░ ░ ░ ▒    ░   ░    ░   ░ ░   ░ ░   ░ ░ ░ ▒    ░   ▒    ░ ░  ░ ");
                    Console.WriteLine("   ░        ░ ░      ░            ░     ░  ░    ░ ░        ░  ░   ░    ");
                    Console.WriteLine(" ░                                                              ░      ");
                    Console.WriteLine("");

                    String pname = "ZunSploit.zip";
                    String dlink = "https://cdn.discordapp.com/attachments/904488718939856899/904488734479757322/ZunSploit.zip";
                    Console.Title = pname + " Bootstrapper";
                    Console.ForegroundColor = ConsoleColor.DarkCyan;
                    Console.WriteLine($"Hello! Welcome to");
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("ZunSploit's Bootstrapper!");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Downloading new Files...");
                    WebClient wc = new WebClient();
                    wc.DownloadFile(dlink, "./ZunSploit.zip");
                    ZipFile.ExtractToDirectory("./ZunSploit.zip", "./");
                    File.Delete("./ZunSploit.zip");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine(pname + " Downloaded | Updated!");
                    Console.WriteLine($"Now open " + "ZunSploit and then " + "ZunSploit.exe");

                    Console.ReadLine();
                    break;
                case 2:
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Clear();
                    Console.WriteLine("▓█████▄  ██▓  ██████  ▄████▄   ▒█████   ██▀███  ▓█████▄ ");
                    Console.WriteLine("▒██▀ ██▌▓██▒▒██    ▒ ▒██▀ ▀█  ▒██▒  ██▒▓██ ▒ ██▒▒██▀ ██▌");
                    Console.WriteLine("░██   █▌▒██▒░ ▓██▄   ▒▓█    ▄ ▒██░  ██▒▓██ ░▄█ ▒░██   █▌");
                    Console.WriteLine("░▓█▄   ▌░██░  ▒   ██▒▒▓▓▄ ▄██▒▒██   ██░▒██▀▀█▄  ░▓█▄   ▌");
                    Console.WriteLine("░▒████▓ ░██░▒██████▒▒▒ ▓███▀ ░░ ████▓▒░░██▓ ▒██▒░▒████▓ ");
                    Console.WriteLine(" ▒▒▓  ▒ ░▓  ▒ ▒▓▒ ▒ ░░ ░▒ ▒  ░░ ▒░▒░▒░ ░ ▒▓ ░▒▓░ ▒▒▓  ▒ ");
                    Console.WriteLine(" ░ ▒  ▒  ▒ ░░ ░▒  ░ ░  ░  ▒     ░ ▒ ▒░   ░▒ ░ ▒░ ░ ▒  ▒ ");
                    Console.WriteLine(" ░ ░  ░  ▒ ░░  ░  ░  ░        ░ ░ ░ ▒    ░░   ░  ░ ░  ░ ");
                    Console.WriteLine("   ░     ░        ░  ░ ░          ░ ░     ░        ░    ");
                    Console.WriteLine(" ░                   ░                           ░      ");
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("");
                    Process.Start("https://discord.gg/xTjxdbfdMw");
                    Console.WriteLine("");

                    Console.ReadLine();
                    break;
                case 3:
                    Process[] processes = Process.GetProcessesByName("ZunSploit");
                    foreach (Process process in processes)
                    {
                        process.Kill();
                        process.WaitForExit();
                    }
                    break;
                case 4:
                    Process[] processesR = Process.GetProcessesByName("Roblox");
                    foreach (Process process in processesR)
                    {
                        process.Kill();
                        process.WaitForExit();
                    }
                    break;
            }
        }
    }
}
