﻿using KeyAuth;
using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Key_Auth
{
    class Program
    {
        static string name = "Exploit"; 
        static string ownerid = "wmhr4h1zF8"; 
        static string secret = "95d8914ea13e1c9a3b53ac816d496906ee4788cf360f913b2dae1a4502325ff7";
        static string version = "1.0";

        public static api KeyAuthApp = new api(name, ownerid, secret, version);

        static async Task Main(string[] args)
        {
            Console.Title = "Auth";
            KeyAuthApp.init();

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("                                           ▒███████▒ █    ██  ███▄    █ ");
            Console.WriteLine("                                           ▒ ▒ ▒ ▄▀░ ██  ▓██▒ ██ ▀█   █ ");
            Console.WriteLine("                                             ▒ ▄▀▒░ ▓██  ▒██░▓██  ▀█ ██▒");
            Console.WriteLine("                                             ▄▀▒   ░▓▓█  ░██░▓██▒  ▐▌██▒");
            Console.WriteLine("                                           ▒███████▒▒▒█████▓ ▒██░   ▓██░");
            Console.WriteLine("                                           ░▒▒ ▓░▒░▒░▒▓▒ ▒ ▒ ░ ▒░   ▒ ▒ ");
            Console.WriteLine("                                           ░░▒ ▒ ░ ▒░░▒░ ░ ░ ░ ░░   ░ ▒░");
            Console.WriteLine("                                           ░ ░ ░ ░ ░ ░░░ ░ ░    ░   ░ ░ ");
            Console.WriteLine("                                           ░ ░       ░              ░   ");
            Console.WriteLine("                                           ░                            ");
            Console.WriteLine("");
            Console.WriteLine("[1] Download");
            Console.WriteLine("[2] Enter Key");
            Console.WriteLine("[3] Get Key");
            Console.WriteLine("");
            Console.WriteLine("[!] Choose option: ");


            string key = "";

            int option = int.Parse(Console.ReadLine());
            switch (option)
            {
                case 1:
                    Console.Clear();
                    Console.WriteLine("                                           ▒███████▒ █    ██  ███▄    █ ");
                    Console.WriteLine("                                           ▒ ▒ ▒ ▄▀░ ██  ▓██▒ ██ ▀█   █ ");
                    Console.WriteLine("                                             ▒ ▄▀▒░ ▓██  ▒██░▓██  ▀█ ██▒");
                    Console.WriteLine("                                             ▄▀▒   ░▓▓█  ░██░▓██▒  ▐▌██▒");
                    Console.WriteLine("                                           ▒███████▒▒▒█████▓ ▒██░   ▓██░");
                    Console.WriteLine("                                           ░▒▒ ▓░▒░▒░▒▓▒ ▒ ▒ ░ ▒░   ▒ ▒ ");
                    Console.WriteLine("                                           ░░▒ ▒ ░ ▒░░▒░ ░ ░ ░ ░░   ░ ▒░");
                    Console.WriteLine("                                           ░ ░ ░ ░ ░ ░░░ ░ ░    ░   ░ ░ ");
                    Console.WriteLine("                                           ░ ░       ░              ░   ");
                    Console.WriteLine("                                           ░                            ");
                    Console.WriteLine("");
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("[!] Downloading DLL's");
                    Console.ForegroundColor = ConsoleColor.Green;
                    await Task.Delay(1300);
                    Console.WriteLine("[!] Downloaded DLL's");
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("[!] Downloading EXE"); 
                    Console.ForegroundColor = ConsoleColor.Green;
                    await Task.Delay(2600);
                    Console.WriteLine("[!] Downloaded EXE");
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("[!] Extracting DLL's");
                    Console.ForegroundColor = ConsoleColor.Green;
                    await Task.Delay(2600);
                    Console.WriteLine("[!] Extracted DLL's");
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("[!] Extracting EXE");
                    Console.ForegroundColor = ConsoleColor.Green;
                    await Task.Delay(3200);
                    Console.WriteLine("[!] Extracted EXE");
                    Console.WriteLine("");
                    Console.WriteLine("");
                    Console.WriteLine("Done, Restart Zun Installer");

                    Console.ReadLine();
                    break;
                case 2:
                    Console.Clear();
                    Console.WriteLine("                                           ▒███████▒ █    ██  ███▄    █ ");
                    Console.WriteLine("                                           ▒ ▒ ▒ ▄▀░ ██  ▓██▒ ██ ▀█   █ ");
                    Console.WriteLine("                                             ▒ ▄▀▒░ ▓██  ▒██░▓██  ▀█ ██▒");
                    Console.WriteLine("                                             ▄▀▒   ░▓▓█  ░██░▓██▒  ▐▌██▒");
                    Console.WriteLine("                                           ▒███████▒▒▒█████▓ ▒██░   ▓██░");
                    Console.WriteLine("                                           ░▒▒ ▓░▒░▒░▒▓▒ ▒ ▒ ░ ▒░   ▒ ▒ ");
                    Console.WriteLine("                                           ░░▒ ▒ ░ ▒░░▒░ ░ ░ ░ ░░   ░ ▒░");
                    Console.WriteLine("                                           ░ ░ ░ ░ ░ ░░░ ░ ░    ░   ░ ░ ");
                    Console.WriteLine("                                           ░ ░       ░              ░   ");
                    Console.WriteLine("                                           ░                            ");
                    Console.WriteLine("");
                    Console.WriteLine("\n\n[!] Enter Key: ");
                    key = Console.ReadLine();
                    KeyAuthApp.license(key);
                    break;
                case 3:
                    Console.Clear();
                    Console.WriteLine("                                           ▒███████▒ █    ██  ███▄    █ ");
                    Console.WriteLine("                                           ▒ ▒ ▒ ▄▀░ ██  ▓██▒ ██ ▀█   █ ");
                    Console.WriteLine("                                             ▒ ▄▀▒░ ▓██  ▒██░▓██  ▀█ ██▒");
                    Console.WriteLine("                                             ▄▀▒   ░▓▓█  ░██░▓██▒  ▐▌██▒");
                    Console.WriteLine("                                           ▒███████▒▒▒█████▓ ▒██░   ▓██░");
                    Console.WriteLine("                                           ░▒▒ ▓░▒░▒░▒▓▒ ▒ ▒ ░ ▒░   ▒ ▒ ");
                    Console.WriteLine("                                           ░░▒ ▒ ░ ▒░░▒░ ░ ░ ░ ░░   ░ ▒░");
                    Console.WriteLine("                                           ░ ░ ░ ░ ░ ░░░ ░ ░    ░   ░ ░ ");
                    Console.WriteLine("                                           ░ ░       ░              ░   ");
                    Console.WriteLine("                                           ░                            ");
                    Console.WriteLine("\n\n[!] Key: https://linkvertise.com/369111/ZunKey?o=sharing");

                    Console.ReadLine();
                    break;
                default:
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\n\n[!] Invalid Selection");
                    Thread.Sleep(3500);
                    Environment.Exit(0);
                    break; // no point in this other than to not get error from IDE
            }

            Console.WriteLine("\n\n[!] Logged In!"); // at this point, the client has been authenticated
            

            
			bool hasFortnite = KeyAuthApp.user_data.subscriptions.Any(x => x.subscription == "fortnite");
            if(hasFortnite) // check if user has subscription with name fortnite
            {
                Console.WriteLine("user has fortnite subscription");
            }


            string filename = Directory.GetCurrentDirectory() + "LicenseSave.txt";
            Console.Write("[!] Licence expiry: ");
            Console.WriteLine(UnixTimeToDateTime(long.Parse(KeyAuthApp.user_data.subscriptions[0].expiry)));
            Console.WriteLine("");
            Console.WriteLine("[!] Saved your licence!");

            if (File.Exists(filename))
            {
                File.Delete(filename);
            }
            else if (!File.Exists(filename))
            {
                File.Create(filename);
            }

            File.WriteAllText(filename, key);
        }

        public static DateTime UnixTimeToDateTime(long unixtime)
        {
            System.DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Local);
            dtDateTime = dtDateTime.AddSeconds(unixtime).ToLocalTime();
            return dtDateTime;
        }
    }
}
