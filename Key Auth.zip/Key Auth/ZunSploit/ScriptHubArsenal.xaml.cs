﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using KrnlAPI;

namespace ZunSploit
{
    /// <summary>
    /// Interaction logic for ScriptHubArsenal.xaml
    /// </summary>
    public partial class ScriptHubArsenal : Window
    {
        CheatSquadAPI.Module module = new CheatSquadAPI.Module();
        EasyExploits.Module moduleEasyExploits = new EasyExploits.Module();
        public ScriptHubArsenal()
        {
            InitializeComponent();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            WebClient web = new WebClient();
            string OwlHub = web.DownloadString("https://raw.githubusercontent.com/CriShoux/OwlHub/master/OwlHub.txt");
            MainWindow main = new MainWindow();
            if (main.EasyExploitsIsChecked == true)
            {
                moduleEasyExploits.ExecuteScript(OwlHub);
            }
            else if (main.CheatSquadIsChecked == true)
            {
                module.Execute(OwlHub);
            }
            else if (main.KRNLIsChecked == true)
            {
                MainAPI.Execute(OwlHub);
            }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            WebClient web = new WebClient();
            string PEV = web.DownloadString("https://raw.githubusercontent.com/Project-Evolution/Main/main/Loader.lua");
            MainWindow main = new MainWindow();
            if (main.EasyExploitsIsChecked == true)
            {
                moduleEasyExploits.ExecuteScript(PEV);
            }
            else if (main.CheatSquadIsChecked == true)
            {
                module.Execute(PEV);
            }
            else if (main.KRNLIsChecked == true)
            {
                MainAPI.Execute(PEV);
            }
        }

        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void Border_MouseMove(object sender, MouseEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }
    }
}
