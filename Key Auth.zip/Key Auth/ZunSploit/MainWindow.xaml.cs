﻿using ICSharpCode.AvalonEdit.Highlighting;
using ICSharpCode.AvalonEdit.Highlighting.Xshd;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;
using KrnlAPI;

namespace ZunSploit
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        CheatSquadAPI.Module module = new CheatSquadAPI.Module();
        EasyExploits.Module moduleEasyExploits = new EasyExploits.Module();

        public bool EasyExploitsIsChecked;
        public bool CheatSquadIsChecked;
        public bool KRNLIsChecked;

        public MainWindow()
        {
            InitializeComponent();

            if (EasyExploitsCheck.IsChecked == true)
            {
                EasyExploitsIsChecked = true;
            }
            else if (EasyExploitsCheck.IsChecked == false)
            {

                EasyExploitsIsChecked = false;
            }

            if (CheatSquad.IsChecked == true)
            {
                CheatSquadIsChecked = true;
            }
            else if (CheatSquad.IsChecked == false)
            {

                CheatSquadIsChecked = false;
            }

            if (KRNApi.IsChecked == true)
            {
                KRNLIsChecked = true;
            }
            else if (KRNApi.IsChecked == false)
            {

                KRNLIsChecked = false;
            }

            ScriptList.Items.Clear();
            Functions.PopulateListBox(ScriptList, "./Scripts", "*.txt");
            Functions.PopulateListBox(ScriptList, "./Scripts", "*.lua");

            this.EditTabs.Loaded += delegate (object source, RoutedEventArgs e)
            {
                this.EditTabs.GetTemplateItem<Button>("AddTabButton").Click += delegate (object s, RoutedEventArgs f)
                {
                    this.MakeTab("", "New Tab");
                };

                TabItem ti = EditTabs.SelectedItem as TabItem;
                ti.GetTemplateItem<Button>("CloseButton").Visibility = Visibility.Hidden;
                ti.GetTemplateItem<Button>("CloseButton").Width = 0;
                ti.Header = "Main Tab";

                this.tabScroller = this.EditTabs.GetTemplateItem<ScrollViewer>("TabScrollViewer");
            };
        }

        Storyboard storyboard = new Storyboard();
        TimeSpan halfsecond = TimeSpan.FromMilliseconds(500);
        TimeSpan second = TimeSpan.FromSeconds(1);

        private IEasingFunction Smooth
        {
            get;
            set;
        }
        = new QuarticEase
        {
            EasingMode = EasingMode.EaseInOut
        };

        public void Fade(DependencyObject Object)
        {
            DoubleAnimation FadeIn = new DoubleAnimation()
            {
                From = 0.0,
                To = 1.0,
                Duration = new Duration(halfsecond),
            };
            Storyboard.SetTarget(FadeIn, Object);
            Storyboard.SetTargetProperty(FadeIn, new PropertyPath("Opacity", 1));
            storyboard.Children.Add(FadeIn);
            storyboard.Begin();
        }

        public void FadeOut(DependencyObject Object)
        {
            DoubleAnimation FadeOut = new DoubleAnimation()
            {
                From = 1.0,
                To = 0.0,
                Duration = new Duration(halfsecond),
            };
            Storyboard.SetTarget(FadeOut, Object);
            Storyboard.SetTargetProperty(FadeOut, new PropertyPath("Opacity", 1));
            storyboard.Children.Add(FadeOut);
            storyboard.Begin();
        }

        public void ObjectShiftPos(DependencyObject Object, Thickness Get, Thickness Set)
        {
            ThicknessAnimation ShiftAnimation = new ThicknessAnimation()
            {
                From = Get,
                To = Set,
                Duration = second,
                EasingFunction = Smooth,
            };
            Storyboard.SetTarget(ShiftAnimation, Object);
            Storyboard.SetTargetProperty(ShiftAnimation, new PropertyPath(MarginProperty));
            storyboard.Children.Add(ShiftAnimation);
            storyboard.Begin();
        } 

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }

        private async void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if (settings.Visibility == Visibility.Hidden)
            {
                settings.Visibility = Visibility.Visible;
                await Task.Delay(500);
                this.ObjectShiftPos(this.settings, settings.Margin, new Thickness(647, 42, 0, 0));
                this.ObjectShiftPos(this.CheatSquad, CheatSquad.Margin, new Thickness(667, 75, 0, 0));
                this.ObjectShiftPos(this.KRNApi, KRNApi.Margin, new Thickness(667, 98, 0, 0));
            }
            else if (settings.Visibility == Visibility.Visible)
            {
                this.ObjectShiftPos(this.settings, settings.Margin, new Thickness(814, 42, -157, 0));
                this.ObjectShiftPos(this.CheatSquad, CheatSquad.Margin, new Thickness(834, 75, -138, 0));
                this.ObjectShiftPos(this.KRNApi, KRNApi.Margin, new Thickness(834, 98, -138, 0));
                await Task.Delay(500);
                settings.Visibility = Visibility.Hidden;
            }
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            ScriptList.Items.Refresh();
        }

        private void ScriptList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            bool flag = this.ScriptList.SelectedIndex != -1;
            if (flag)
            {
                AvalonEditor.Text = File.ReadAllText("Scripts\\" + this.ScriptList.SelectedItem.ToString());
            }
        }

        private void Border_MouseMove(object sender, MouseEventArgs e)
        {

        }

        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private ScrollViewer tabScroller;
        private void ScrollTabs(object sender, MouseWheelEventArgs e)
        {

            this.tabScroller.ScrollToHorizontalOffset(this.tabScroller.HorizontalOffset + (double)(e.Delta / 10));
        }
        private void MoveTab(object sender, MouseEventArgs e)
        {
            TabItem tabItem = e.Source as TabItem;
            if (tabItem == null)
            {
                return;
            }
            if (Mouse.PrimaryDevice.LeftButton == MouseButtonState.Pressed)
            {
                if (VisualTreeHelper.HitTest(tabItem, Mouse.GetPosition(tabItem)).VisualHit is Button)
                {
                    return;
                }
                DragDrop.DoDragDrop(tabItem, tabItem, DragDropEffects.Move);
            }
        }
        private ICSharpCode.AvalonEdit.TextEditor current;

        public ICSharpCode.AvalonEdit.TextEditor GetCurrent()
        {
            if (this.EditTabs.Items.Count == 0)
            {
                return AvalonEditor;
            }
            else
            {
                return this.current = (this.EditTabs.SelectedContent as ICSharpCode.AvalonEdit.TextEditor);
            }
        }

        public ICSharpCode.AvalonEdit.TextEditor MakeEditor()
        {
            ICSharpCode.AvalonEdit.TextEditor textEditor = new ICSharpCode.AvalonEdit.TextEditor
            {
                ShowLineNumbers = true,
                Background = new SolidColorBrush(System.Windows.Media.Color.FromRgb(22, 22, 22)),
                Foreground = new SolidColorBrush((System.Windows.Media.Color.FromRgb(255, 255, 255))),
                Margin = new Thickness(2, 5, 7, -11),
                FontFamily = new System.Windows.Media.FontFamily("Consolas"),
                Style = (this.TryFindResource("TextEditorStyle1") as Style),
                HorizontalScrollBarVisibility = ScrollBarVisibility.Visible,
                VerticalScrollBarVisibility = ScrollBarVisibility.Visible
            };
            textEditor.Options.EnableEmailHyperlinks = false;
            textEditor.Options.EnableHyperlinks = false;
            textEditor.Options.AllowScrollBelowDocument = true;

            return textEditor;
        }
        public TabItem MakeTab(string text = "", string title = "Tab")
        {
            title = title + "";
            bool loaded = false;
            ICSharpCode.AvalonEdit.TextEditor textEditor = MakeEditor();
            textEditor.Text = text;
            TabItem tab = new TabItem
            {
                Content = textEditor,
                Style = (base.TryFindResource("Tab") as Style),
                AllowDrop = true,
                Header = title
            };
            tab.MouseWheel += this.ScrollTabs;
            tab.Loaded += delegate (object source, RoutedEventArgs e)
            {
                if (loaded)
                {
                    return;
                }
                this.tabScroller.ScrollToRightEnd();
                loaded = true;
            };
            tab.MouseDown += delegate (object sender, MouseButtonEventArgs e)
            {
                if (e.OriginalSource is Border)
                {
                    if (e.MiddleButton == MouseButtonState.Pressed)
                    {
                        this.EditTabs.Items.Remove(tab);
                        return;
                    }
                }
            };
            tab.Loaded += delegate (object s, RoutedEventArgs e)
            {
                tab.GetTemplateItem<Button>("CloseButton").Click += delegate (object r, RoutedEventArgs f)
                {
                    this.EditTabs.Items.Remove(tab);
                };

                this.tabScroller.ScrollToRightEnd();
                loaded = true;
            };

            tab.MouseMove += this.MoveTab;
            tab.Drop += this.DropTab;
            string oldHeader = title;
            this.EditTabs.SelectedIndex = this.EditTabs.Items.Add(tab);
            return tab;
        }
        private void Rectangle_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }
        private void Ellipse_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.Close();
        }
        private void EditTabs_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void DropTab(object sender, DragEventArgs e)
        {
            TabItem tabItem = e.Source as TabItem;
            if (tabItem != null)
            {
                TabItem tabItem2 = e.Data.GetData(typeof(TabItem)) as TabItem;
                if (tabItem2 != null)
                {
                    if (!tabItem.Equals(tabItem2))
                    {
                        TabControl tabControl = tabItem.Parent as TabControl;
                        int insertIndex = tabControl.Items.IndexOf(tabItem2);
                        int num = tabControl.Items.IndexOf(tabItem);
                        tabControl.Items.Remove(tabItem2);
                        tabControl.Items.Insert(num, tabItem2);
                        tabControl.Items.Remove(tabItem);
                        tabControl.Items.Insert(insertIndex, tabItem);
                        tabControl.SelectedIndex = num;
                    }
                    return;
                }
            }
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            if (EasyExploitsCheck.IsChecked == true)
            {
                moduleEasyExploits.LaunchExploit();
            }
            else if (CheatSquad.IsChecked == true)
            {
                module.Attach();
            }
            else if (KRNApi.IsChecked == true)
            {
                MainAPI.Inject();
            }
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            if (EasyExploitsCheck.IsChecked == true)
            {
                moduleEasyExploits.ExecuteScript(AvalonEditor.Text);
            }
            else if (CheatSquad.IsChecked == true)
            {
                module.Execute(AvalonEditor.Text);
            }
            else if (KRNApi.IsChecked == true)
            {
                MainAPI.Execute(AvalonEditor.Text);
            }
        }

        private void KRNApi_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            Script_hub hub = new Script_hub();
            hub.Show();
        }

        private void CheatSquad_Checked(object sender, RoutedEventArgs e)
        {

        }
    }
}
