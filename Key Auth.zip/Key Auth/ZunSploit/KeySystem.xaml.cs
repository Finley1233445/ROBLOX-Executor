﻿using KeyAuth;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ZunSploit
{
    /// <summary>
    /// Interaction logic for KeySystem.xaml
    /// </summary>
    public partial class KeySystem : Window
    {
        static string name = "Exploit";
        static string ownerid = "wmhr4h1zF8";
        static string secret = "95d8914ea13e1c9a3b53ac816d496906ee4788cf360f913b2dae1a4502325ff7";
        static string version = "1.3";

        public static api KeyAuthApp = new api(name, ownerid, secret, version);
        public KeySystem()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if (KeyAuthApp.license(Textbox1.Text))
            {
                MainWindow main = new MainWindow();
                main.Show();
                this.Hide();
            }
        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            KeyAuthApp.init();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Process.Start("https://link-center.net/369111/ZunKey3");
        }

        private void Border_MouseMove(object sender, MouseEventArgs e)
        {
        }

        private void Border_MouseEnter(object sender, MouseEventArgs e)
        {

        }

        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
        }

        private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }
    }
}
